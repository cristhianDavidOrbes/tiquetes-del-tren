/**
 * 
 */
/**
 * 
 */
module project_animal {
}