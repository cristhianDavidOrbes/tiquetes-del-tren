package project_animal;

public class ejecutar {

    public static void main(String[] args) {
 
        Animal genericAnimal = new Animal("GenericAnimal");
        Mammal genericMammal = new Mammal("GenericMammal");
        Cat cat = new Cat("Kitty");
        Dog dog = new Dog("Rex");
        Dog anotherDog = new Dog("Max");

 
        System.out.println(genericAnimal.toString());
        System.out.println(genericMammal.toString());
        System.out.println(cat.toString());
        System.out.println(dog.toString());

     
        cat.greets(); 
        dog.greets(); 
        dog.greets(anotherDog);
    }
}
