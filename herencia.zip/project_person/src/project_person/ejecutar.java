package project_person;



public class ejecutar {

    public static void main(String[] args) {
        
      
        Person person = new Person("John Doe", "123 Main St");
        System.out.println(person.toString());

    
        Student student = new Student("Jane Doe", "456 College Ave", "Computer Science", 2023, 15000.50);
        System.out.println(student.toString());

   
        Staff staff = new Staff("Emily Smith", "789 University Blvd", "Engineering School", 45000.75);
        System.out.println(staff.toString());
    }
}
