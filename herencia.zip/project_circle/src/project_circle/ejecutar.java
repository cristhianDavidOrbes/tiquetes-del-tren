package project_circle;



public class ejecutar {
    public static void main(String[] args) {
   
        Cylinder myCylinder = new Cylinder(5, 10, "blue");


        System.out.println("Surface area of the cylinder: " + myCylinder.getArea());

 
        System.out.println("Volume of the cylinder: " + myCylinder.getVolume());

    
        System.out.println("Color of the cylinder: " + myCylinder.getColor());


        System.out.println("Radius of the cylinder: " + myCylinder.getRadius());

     
        System.out.println("Height of the cylinder: " + myCylinder.getHeight());
    }
}