package project_Shape;



public class ejecutar {

    public static void main(String[] args) {

      
        Shape shape = new Shape();
        System.out.println("Default Shape: " + shape.toString());

        shape.setColor("blue");
        shape.setFilled(false);
        System.out.println("Updated Shape: " + shape.toString());
        System.out.println("Is filled: " + shape.isFilled());
        System.out.println();

      
        Circle circle = new Circle(5.0, "green", true);
        System.out.println("Circle: " + circle.toString());
        System.out.println("Area of Circle: " + circle.getArea());
        System.out.println("Perimeter of Circle: " + circle.getPerimetro());
        circle.setRadius(7.0);
        System.out.println("Updated Circle Radius: " + circle.getRadius());
        System.out.println();


        Rectangle rectangle = new Rectangle(4.0, 6.0, "yellow", false);
        System.out.println("Rectangle: " + rectangle.toString());
        System.out.println("Area of Rectangle: " + rectangle.getArea());
        System.out.println("Perimeter of Rectangle: " + rectangle.getPerimetro());
        rectangle.setWidth(5.0);
        rectangle.setLength(8.0);
        System.out.println("Updated Rectangle Width and Length: " + rectangle.getWidth() + ", " + rectangle.getLength());
        System.out.println();


        Square square = new Square(4.0, "purple", true);
        System.out.println("Square: " + square.toString());
        square.setSide(6.0);
        System.out.println("Updated Square Side: " + square.getSide());
        System.out.println("Updated Square: " + square.toString());
    }
}
